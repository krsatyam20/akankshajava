public class Ifelse {

	public static void main(String[] args) {
	int x=20;
	int y=10;
	int z;
		
  if(y>0) {
	  //True
	  z=x/y;
		System.out.println(z);
			 
	  //System.out.println("A is Gt");
  }
  else
  {

	  System.out.println("Not Divided  by Zero ");
  }
 
			
	}

}
