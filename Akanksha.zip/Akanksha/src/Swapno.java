
public class Swapno {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int x=10;
int y =20;
System.out.println("========Before Swape============");

System.out.println(x +"========" +y);
x=x+y; //30
y=x-y; //10
x=x-y;  //20
System.out.println("========After Swape============");

System.out.println(x +"========" +y);
	}

}
