
public class Myfirstprogram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	int x=20;
	int y=10;
    String name="Akanksha" ; 
	
	int z;
	System.out.print("hello ");	

	System.out.println("student " + name);

	//System.out.println("Ak");
	z= x+y;
	
	System.out.println("Add Value of x and y ="+z);
	
     z= x-y;
	
	System.out.println("Sub Value of x and y ="+z);
	
	
	}

}
