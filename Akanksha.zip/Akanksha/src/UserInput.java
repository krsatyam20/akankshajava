import java.util.Scanner; 
public class UserInput {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int x,y,z;
String name;
Scanner obj = new Scanner(System.in); 
System.out.println("Please enter the Name");
name=obj.next();
System.out.println("Please enter the 1st number");
x=obj.nextInt();
System.out.println("Please enter the 2nd number");
y=obj.nextInt();
z=x+y;
System.out.println("Add value of"+ x +"and" +y +"= "+ z +"Name=" +name);

obj.close();
		
	}

}
